import React from "react";

export const ViewBook = () => {
  return <div>Hola mundo</div>;
};
